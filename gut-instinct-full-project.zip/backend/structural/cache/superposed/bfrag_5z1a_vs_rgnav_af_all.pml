#!/usr/bin/env pymol
load /Users/rithika/Desktop/Gut_instinct/MedXHackathon/gut-instinct-/backend/structural/cache/superposed/bfrag_5z1a_vs_rgnav_af_all, format=pdb
hide all
show stick
color blue, chain A
color red, chain B
set ray_shadow, 0
set stick_radius, 0.3
set sphere_scale, 0.25
show stick, not polymer
show sphere, not polymer
bg_color white
set transparency=0.2
zoom polymer

